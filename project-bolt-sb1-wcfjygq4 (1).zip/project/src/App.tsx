import React, { useEffect } from 'react';
import { Outlet, useRouter } from '@tanstack/react-router';
import { useTranslation } from 'react-i18next';
import { Disc as Discord, Heart } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import Navbar from './components/Navbar';
import ParticleBackground from './components/ParticleBackground';

function App() {
  const router = useRouter();
  const { t } = useTranslation();

  // Scroll to top on route change
  useEffect(() => {
    const unsubscribe = router.subscribe('onBeforeLoad', () => {
      window.scrollTo(0, 0);
    });
    return () => unsubscribe();
  }, [router]);

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 relative flex flex-col">
      <ParticleBackground />
      <Navbar />
      <div className="flex-grow">
        <Outlet />
      </div>
      
      <AnimatePresence mode="wait">
        <motion.footer 
          key={router.state.location.pathname}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
          className="relative mt-20"
        >
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
            className="absolute inset-0 bg-gradient-to-b from-transparent via-purple-900/10 to-black/40"
          />
          
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.4, delay: 0.1 }}
            className="relative border-t border-gray-800"
          >
            <div className="container mx-auto px-4 py-12">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
                {/* About Section */}
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.4, delay: 0.2 }}
                >
                  <div className="flex items-center gap-2 mb-4">
                    <img src="/logo copy.png" alt="TPT Lab Logo" className="w-8 h-8" />
                    <h3 className="text-xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                      TPT Lab
                    </h3>
                  </div>
                  <p className="text-gray-400 mb-4">
                    Tallinna Polütehnikumi õpilaste loodud Minecraft server, mis on mõeldud kõigile MC mängijatele.
                  </p>
                </motion.div>

                {/* School Info */}
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.4, delay: 0.3 }}
                >
                  <h3 className="text-lg font-semibold text-white mb-4">Meie Kool</h3>
                  <div className="space-y-2 text-gray-400">
                    <p>Tallinna Polütehnikum</p>
                    <p>Pärnu mnt 57, Tallinn</p>
                    <a 
                      href="https://www.tptlive.ee" 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="text-purple-400 hover:text-purple-300 transition-colors"
                    >
                      www.tptlive.ee
                    </a>
                  </div>
                </motion.div>

                {/* Quick Links */}
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.4, delay: 0.4 }}
                >
                  <h3 className="text-lg font-semibold text-white mb-4">Kiirlingid</h3>
                  <ul className="space-y-2">
                    <li>
                      <a href="/wiki" className="text-gray-400 hover:text-white transition-colors">Wiki</a>
                    </li>
                    <li>
                      <a href="/rules" className="text-gray-400 hover:text-white transition-colors">Reeglid</a>
                    </li>
                    <li>
                      <a href="/map" className="text-gray-400 hover:text-white transition-colors">Kaart</a>
                    </li>
                  </ul>
                </motion.div>

                {/* Server Info */}
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.4, delay: 0.5 }}
                >
                  <h3 className="text-lg font-semibold text-white mb-4">Server</h3>
                  <div className="space-y-2 text-gray-400">
                    <p className="font-mono bg-gray-800/50 px-3 py-2 rounded-lg">
                      mc.tptlab.eu
                    </p>
                    <p>Versioonid: 1.21 - 1.21.4</p>
                    <a 
                      href="https://discord.gg/DJaTZs7Wxn" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 text-purple-400 hover:text-purple-300 transition-colors"
                    >
                      <Discord className="w-4 h-4" />
                      Liitu Discordiga
                    </a>
                  </div>
                </motion.div>
              </div>

              {/* Bottom Bar */}
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.4, delay: 0.6 }}
                className="pt-8 border-t border-gray-800/50 text-center"
              >
                <div className="text-gray-400 text-sm flex items-center justify-center gap-1">
                  © 2025 TPT Lab. Tehtud <Heart className="w-4 h-4 text-red-400" /> Eestis
                </div>
              </motion.div>
            </div>
          </motion.div>
        </motion.footer>
      </AnimatePresence>
    </div>
  );
}

export default App;