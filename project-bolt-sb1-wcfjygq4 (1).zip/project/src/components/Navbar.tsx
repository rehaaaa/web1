import React from 'react';
import { Link, useRouter } from '@tanstack/react-router';
import { Home, Book, Map, Info, Disc as Discord, Shield } from 'lucide-react';

const Navbar: React.FC = () => {
  const router = useRouter();
  
  const navItems = [
    { name: 'Esileht', href: '/', icon: Home },
    { name: 'Wiki', href: '/wiki', icon: Book },
    { name: 'Kaart', href: '/maailmakaart', icon: Map },
    { name: 'Reeglid', href: '/reeglid', icon: Shield },
  ];

  const isActive = (path: string) => {
    return router.state.location.pathname === path;
  };

  return (
    <nav className="fixed w-full z-50 top-0">
      <div className="navbar-blur">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-20">
            <Link 
              to="/" 
              className="flex items-center space-x-3 group"
            >
              <div className="relative w-10 h-10">
                <div className="absolute inset-0 bg-purple-500/20 rounded-lg blur-lg group-hover:bg-purple-500/30 transition-colors"></div>
                <img
                  src="/logo copy.png"
                  alt="TPT Lab Logo"
                  className="relative w-full h-full object-contain"
                />
              </div>
              <span className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-fuchsia-500 bg-clip-text text-transparent font-minecraft">
                TPT Lab
              </span>
            </Link>

            <div className="hidden md:flex items-center space-x-4">
              {navItems.map((item) => (
                <Link
                  key={item.name}
                  to={item.href}
                  className={`px-4 py-2 rounded-lg flex items-center gap-2 transition-all duration-300 ${
                    isActive(item.href)
                      ? 'bg-gradient-to-r from-purple-500/20 to-blue-500/20 text-white'
                      : 'text-gray-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <item.icon className="w-4 h-4" />
                  <span>{item.name}</span>
                </Link>
              ))}
              
              <a
                href="https://discord.gg/DJaTZs7Wxn"
                target="_blank"
                rel="noopener noreferrer"
                className="minecraft-btn flex items-center gap-2 purple-glow"
              >
                <Discord className="w-4 h-4" />
                <span>Discord</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;