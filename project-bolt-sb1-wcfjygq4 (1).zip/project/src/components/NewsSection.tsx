import React from 'react';
import { motion } from 'framer-motion';
import { Bell, ChevronRight } from 'lucide-react';
import { useTranslation } from 'react-i18next';

const NewsSection: React.FC = () => {
  const { t } = useTranslation();
  
  const news = [
    {
      id: 1,
      date: '2024-03-15',
      title: 'Uus Maailm Avatud!',
      content: 'Oleme avanud uue maailma koos põnevate seiklustega. Tule ja avasta!',
      image: 'https://images.unsplash.com/photo-1591123120675-6f7f1aae0e5b?auto=format&fit=crop&q=80&w=300',
    },
    {
      id: 2,
      date: '2024-03-10',
      title: 'Serveri Uuendused',
      content: 'Värskendasime serveri tarkvara ja lisasime uusi funktsioone parema mängukogemuse jaoks.',
      image: 'https://images.unsplash.com/photo-1587573089734-09cb69c0f2b4?auto=format&fit=crop&q=80&w=300',
    },
  ];

  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex items-center gap-3 mb-8"
        >
          <Bell className="w-6 h-6 text-emerald-400" />
          <h2 className="minecraft text-3xl bg-gradient-to-r from-emerald-400 to-blue-500 bg-clip-text text-transparent">
            Uudised
          </h2>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-6">
          {news.map((item, index) => (
            <motion.article
              key={item.id}
              initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              whileHover={{ scale: 1.02 }}
              className="minecraft-panel bg-gray-800/50 overflow-hidden group"
            >
              <div className="relative h-48 overflow-hidden">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900 to-transparent" />
                <span className="absolute bottom-4 left-4 text-sm text-gray-300 minecraft">
                  {item.date}
                </span>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold text-emerald-400 mb-3 minecraft">
                  {item.title}
                </h3>
                <p className="text-gray-300 mb-4">{item.content}</p>
                <motion.button
                  whileHover={{ x: 5 }}
                  className="minecraft-btn bg-emerald-600 hover:bg-emerald-500 inline-flex items-center gap-2"
                >
                  Loe edasi
                  <ChevronRight className="w-4 h-4" />
                </motion.button>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
};

export default NewsSection;