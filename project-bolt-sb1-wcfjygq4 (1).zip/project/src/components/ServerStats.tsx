import React from 'react';
import { Users, Clock, Activity } from 'lucide-react';

interface ServerStatsProps {
  serverInfo: {
    players: number;
    tps: number;
    uptime: string;
  };
}

const ServerStats: React.FC<ServerStatsProps> = ({ serverInfo }) => {
  return (
    <section className="grid grid-cols-1 md:grid-cols-3 gap-6 py-12">
      <div className="group bg-gray-800/30 backdrop-blur-sm p-6 rounded-xl border border-gray-700/50 hover:border-emerald-500/50 transition-all hover:scale-105">
        <div className="flex items-center mb-4">
          <Users className="w-6 h-6 text-emerald-400 mr-2 transform transition-transform group-hover:scale-110" />
          <h3 className="text-lg font-semibold">Mängijad</h3>
        </div>
        <p className="text-3xl font-bold bg-gradient-to-r from-emerald-400 to-green-500 bg-clip-text text-transparent">
          {serverInfo.players}
        </p>
      </div>

      <div className="group bg-gray-800/30 backdrop-blur-sm p-6 rounded-xl border border-gray-700/50 hover:border-blue-500/50 transition-all hover:scale-105">
        <div className="flex items-center mb-4">
          <Activity className="w-6 h-6 text-blue-400 mr-2 transform transition-transform group-hover:scale-110" />
          <h3 className="text-lg font-semibold">TPS</h3>
        </div>
        <p className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-indigo-500 bg-clip-text text-transparent">
          {serverInfo.tps}
        </p>
      </div>

      <div className="group bg-gray-800/30 backdrop-blur-sm p-6 rounded-xl border border-gray-700/50 hover:border-purple-500/50 transition-all hover:scale-105">
        <div className="flex items-center mb-4">
          <Clock className="w-6 h-6 text-purple-400 mr-2 transform transition-transform group-hover:scale-110" />
          <h3 className="text-lg font-semibold">Uptime</h3>
        </div>
        <p className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent">
          {serverInfo.uptime}
        </p>
      </div>
    </section>
  );
};

export default ServerStats;