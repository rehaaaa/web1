import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources: {
      et: {
        translation: {
          nav: {
            home: 'Pealeht',
            wiki: 'Wiki',
            map: 'Kaart',
            howToPlay: 'Kuidas Mängida?'
          },
          hero: {
            title: 'Tere tulemast TPT Labi',
            description: 'Eesti esimene täielikult tasuta Minecraft server, kus kõik mängijad on võrdsed. Meil pole Pay-to-Win süsteemi!',
            joinDiscord: 'Liitu Discordiga',
            howToPlay: 'Kuidas Mängida?'
          },
          stats: {
            serverTimes: 'SERVERI AJAD',
            status: 'SERVERI OLEK',
            nextEvent: 'JÄRGMINE ÜRITUS'
          },
          serverTimes: {
            weekdays: 'P-N: 07:00 - 00:00',
            weekend: 'R-L: 24/7'
          },
          features: {
            title: 'Serveri Funktsioonid',
            survival: {
              title: 'Survival Maailm',
              description: 'Ehita, kaeva ja avasta koos sõpradega. Claimitud alad kaitsevad sinu ehitisi.'
            },
            economy: {
              title: 'Majandussüsteem',
              description: 'Teeni raha läbi töökohtade, loo oma pood ja kauple teistega.'
            },
            pvp: {
              title: 'PvP & Üritused',
              description: 'Osale põnevates PvP turniirides ja serveri sündmustes.'
            }
          }
        }
      },
      en: {
        translation: {
          nav: {
            home: 'Home',
            wiki: 'Wiki',
            map: 'Map',
            howToPlay: 'How to Play?'
          },
          hero: {
            title: 'Welcome to TPT Lab',
            description: 'Estonia\'s first completely free Minecraft server where all players are equal. We have no Pay-to-Win system!',
            joinDiscord: 'Join Discord',
            howToPlay: 'How to Play?'
          },
          stats: {
            serverTimes: 'SERVER TIMES',
            status: 'SERVER STATUS',
            nextEvent: 'NEXT EVENT'
          },
          serverTimes: {
            weekdays: 'Sun-Thu: 07:00 - 00:00',
            weekend: 'Fri-Sat: 24/7'
          },
          features: {
            title: 'Server Features',
            survival: {
              title: 'Survival World',
              description: 'Build, mine, and explore with friends. Protected areas safeguard your builds.'
            },
            economy: {
              title: 'Economy System',
              description: 'Earn money through jobs, create your shop, and trade with others.'
            },
            pvp: {
              title: 'PvP & Events',
              description: 'Participate in exciting PvP tournaments and server events.'
            }
          }
        }
      }
    },
    fallbackLng: 'et',
    lng: 'et', // Set default language to Estonian
    interpolation: {
      escapeValue: false
    }
  });

export default i18n;