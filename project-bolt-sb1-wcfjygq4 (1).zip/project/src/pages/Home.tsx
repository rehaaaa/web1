import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { motion, AnimatePresence } from 'framer-motion';
import { Clock, Signal, Users, Sword, Coins, Sparkles, Disc as Discord, Shield, Wand2, Cloud, Calendar, Bell, ChevronRight, X } from 'lucide-react';
import { Link } from '@tanstack/react-router';

const Home: React.FC = () => {
  const { t } = useTranslation();
  const [selectedNews, setSelectedNews] = useState<typeof news[0] | null>(null);

  const news = [
    {
      id: 1,
      date: '28.02.2025',
      title: 'BETA Versiooni Avamine',
      content: 'Avasime BETA versiooni MC Serveri. Ootame kõiki testima ja tagasisidet andma!',
      image: 'https://images.unsplash.com/photo-1591123120675-6f7f1aae0e5b?auto=format&fit=crop&q=80&w=800',
      category: 'Uuendus',
      color: 'emerald',
      fullContent: 'Avasime BETA versiooni MC Serveri. See on põnev samm meie serveri arengus, kus saate testida kõiki uusi funktsioone enne ametlikku avalikustamist. Ootame teie tagasisidet ja ettepanekuid, et muuta server veelgi paremaks!'
    },
    {
      id: 2,
      date: '25.03.2025',
      title: '1.0 Serveri Avamine',
      content: 'Avame 1.0 Serveri koos paljude uuenduste ja uute pluginatega!',
      image: 'https://images.unsplash.com/photo-1587573089734-09cb69c0f2b4?auto=format&fit=crop&q=80&w=800',
      category: 'Tehniline',
      color: 'blue',
      fullContent: 'Avame 25.03.2025 1.0 Serveri kus on väga palju uuendusi koos uute pluginatega. Oleme töötanud kõvasti, et tuua teieni parim mängukogemus. Uued pluginad ja funktsioonid muudavad mängimise veelgi põnevamaks!'
    },
    {
      id: 3,
      date: '23.03.2025',
      title: 'TPT Parkouri Üritus',
      content: 'TPT õpilastele toimub põnev parkouri üritus! Tule näita oma oskusi!',
      image: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=800',
      category: 'Üritus',
      color: 'purple',
      fullContent: 'Toimub TPT õpilastel Parkouri üritus! See on suurepärane võimalus näidata oma parkouri oskusi ja võistelda teiste õpilastega. Üritus toimub spetsiaalselt loodud parkouri rajal. Parimaid ootavad auhinnad!'
    }
  ];

  return (
    <div className="relative min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-[80vh] flex items-center">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, type: "spring" }}
              className="relative inline-block mb-8"
            >
              <div className="absolute -inset-4 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-full blur-xl opacity-30 animate-pulse"></div>
              <img
                src="/logo copy.png"
                alt="TPT Lab Logo"
                className="w-32 h-32 relative z-10"
              />
            </motion.div>
            
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="minecraft text-6xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent mb-6"
            >
              {t('hero.title')}
            </motion.h1>
            
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="text-xl text-blue-100/80 mb-8"
            >
              {t('hero.description')}
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.6 }}
              className="flex flex-col sm:flex-row gap-4 justify-center"
            >
              <Link
                to="/how-to-play"
                className="minecraft-btn group relative overflow-hidden"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-cyan-600 group-hover:scale-110 transition-transform duration-500"></div>
                <span className="relative flex items-center justify-center gap-2">
                  <Sparkles className="w-5 h-5" />
                  {t('hero.howToPlay')}
                </span>
              </Link>

              <motion.a
                href="https://discord.gg/DJaTZs7Wxn"
                target="_blank"
                rel="noopener noreferrer"
                className="minecraft-btn group relative overflow-hidden"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-indigo-600 to-purple-600 group-hover:scale-110 transition-transform duration-500"></div>
                <span className="relative flex items-center justify-center gap-2">
                  <Discord className="w-5 h-5" />
                  {t('hero.joinDiscord')}
                </span>
              </motion.a>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Server Stats */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { 
                icon: Clock, 
                label: t('stats.serverTimes'), 
                value: (
                  <div className="space-y-1">
                    <p>{t('serverTimes.weekdays')}</p>
                    <p>{t('serverTimes.weekend')}</p>
                  </div>
                ), 
                color: "blue" 
              },
              { icon: Calendar, label: "JÄRGMINE ÜRITUS", value: "PvP Turniir areenas - 27.03.2025  ", color: "purple" },
              { icon: Signal, label: "SERVERID TALLINNAS", value: "Hea asukoha tõttu on mängijatel hea ping", color: "emerald" }
            ].map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="relative group"
              >
                <div className={`absolute -inset-1 bg-gradient-to-r from-${stat.color}-500 to-${stat.color}-400 rounded-lg blur opacity-20 group-hover:opacity-30 transition-opacity`}></div>
                <div className="relative bg-black/50 backdrop-blur-xl border border-white/10 rounded-lg p-6">
                  <div className="flex items-center gap-4">
                    <stat.icon className={`w-6 h-6 text-${stat.color}-400`} />
                    <div>
                      <p className="text-sm text-gray-400">{stat.label}</p>
                      <div className={`text-2xl font-bold text-${stat.color}-400`}>{stat.value}</div>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* News Section */}
      <section className="py-16 relative">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="flex items-center gap-3 mb-12"
          >
            <Bell className="w-8 h-8 text-purple-400" />
            <h2 className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent">
              Uudised
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-6">
            {news.map((item, index) => (
              <motion.article
                key={item.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="group relative"
              >
                <div className={`absolute -inset-0.5 bg-gradient-to-r from-${item.color}-500 to-${item.color}-400 rounded-xl opacity-0 group-hover:opacity-100 blur transition duration-500`}></div>
                <div className="relative bg-black/50 backdrop-blur-xl rounded-xl overflow-hidden border border-white/10 group-hover:border-transparent transition duration-500">
                  <div className="relative h-48 overflow-hidden">
                    <img
                      src={item.image}
                      alt={item.title}
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-60"></div>
                    <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium bg-${item.color}-500/20 text-${item.color}-400 backdrop-blur-sm`}>
                        {item.category}
                      </span>
                      <span className="text-sm text-gray-300 font-mono">
                        {item.date}
                      </span>
                    </div>
                  </div>
                  
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-white mb-2 group-hover:text-purple-400 transition-colors">
                      {item.title}
                    </h3>
                    <p className="text-gray-400 mb-4">
                      {item.content}
                    </p>
                    <button 
                      onClick={() => setSelectedNews(item)}
                      className="flex items-center gap-2 text-purple-400 hover:text-purple-300 transition-colors group/btn"
                    >
                      <span>Loe edasi</span>
                      <ChevronRight className="w-4 h-4 transform transition-transform group-hover/btn:translate-x-1" />
                    </button>
                  </div>
                </div>
              </motion.article>
            ))}
          </div>
        </div>
      </section>

      {/* News Modal */}
      <AnimatePresence>
        {selectedNews && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
            onClick={() => setSelectedNews(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative max-w-2xl w-full bg-gray-900 rounded-xl overflow-hidden"
              onClick={e => e.stopPropagation()}
            >
              <div className="relative h-64">
                <img
                  src={selectedNews.image}
                  alt={selectedNews.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900 to-transparent"></div>
                <button
                  onClick={() => setSelectedNews(null)}
                  className="absolute top-4 right-4 p-2 rounded-full bg-black/50 text-white hover:bg-black/70 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <span className={`px-3 py-1 rounded-full text-sm font-medium bg-${selectedNews.color}-500/20 text-${selectedNews.color}-400`}>
                    {selectedNews.category}
                  </span>
                  <span className="text-gray-400 font-mono">{selectedNews.date}</span>
                </div>
                <h3 className="text-2xl font-bold text-white mb-4">{selectedNews.title}</h3>
                <p className="text-gray-300 leading-relaxed">{selectedNews.fullContent}</p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Server Features */}
      <section className="py-20 relative">
        <div className="container mx-auto px-4 relative">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold bg-gradient-to-r from-purple-400 via-blue-400 to-emerald-400 bg-clip-text text-transparent mb-4">
              Serveri Võimalused
            </h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Avasta TPT Lab serveri unikaalsed funktsioonid ja eelised
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: Wand2,
                title: "Custom Enchantid",
                description: "Unikaalsed loitsud ja võimed, mis teevad mängimise põnevamaks. Avasta erilisi enchante, mida mujal ei leia!",
                gradient: "from-purple-500 to-pink-500"
              },
              {
                icon: Cloud,
                title: "Realistic Seasons",
                description: "Dünaamiline ilmasüsteem aastaegadega - kevad, suvi, sügis ja talv mõjutavad mängumaailma.",
                gradient: "from-blue-500 to-cyan-500"
              },
              {
                icon: Shield,
                title: "Turvaline Mängimine",
                description: "Claimitud alad kaitsevad sinu ehitisi. Moderaatorid tagavad serveri turvalisuse.",
                gradient: "from-emerald-500 to-teal-500"
              },
              {
                icon: Coins,
                title: "Majandussüsteem",
                description: "Täielik majandussüsteem poodide, töökohade ja kauplemisega. Teeni ja kasvata oma rikkust!",
                gradient: "from-amber-500 to-orange-500"
              },
              {
                icon: Sword,
                title: "PvP & Üritused",
                description: "Spetsiaalne PvP ala, iganädalased turniirid ja põnevad serveri sündmused.",
                gradient: "from-red-500 to-rose-500"
              },
              {
                icon: Users,
                title: "Aktiivne Kogukond",
                description: "Sõbralik mängijaskond ja abivalmis moderaatorid. Leia uusi sõpru ja liitu meeskondadega!",
                gradient: "from-indigo-500 to-violet-500"
              }
            ].map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="group relative"
              >
                <div className={`absolute -inset-0.5 rounded-xl bg-gradient-to-r ${feature.gradient} opacity-0 group-hover:opacity-100 blur transition duration-500`} />
                <div className="relative bg-black/50 backdrop-blur-xl rounded-xl p-8 border border-white/10 group-hover:border-transparent transition duration-500 h-full">
                  <div className={`w-16 h-16 mb-6 rounded-lg bg-gradient-to-r ${feature.gradient} p-0.5 transform group-hover:scale-110 transition duration-500`}>
                    <div className="w-full h-full bg-black rounded-[7px] flex items-center justify-center">
                      <feature.icon className="w-8 h-8 text-white" />
                    </div>
                  </div>
                  <h3 className="text-xl font-bold text-white mb-4 group-hover:bg-gradient-to-r group-hover:bg-clip-text group-hover:text-transparent transition-all duration-500"
                      style={{ backgroundImage: `linear-gradient(to right, ${feature.gradient.split(' ')[1]}, ${feature.gradient.split(' ')[3]})` }}>
                    {feature.title}
                  </h3>
                  <p className="text-gray-400 group-hover:text-gray-300 transition-colors duration-500">
                    {feature.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;