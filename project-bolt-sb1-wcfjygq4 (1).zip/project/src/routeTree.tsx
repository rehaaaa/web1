import { createRootRoute, createRoute, createRouter } from '@tanstack/react-router';
import App from './App';
import Home from './pages/Home';
import Wiki from './pages/Wiki';
import Map from './pages/Map';
import HowToPlay from './pages/HowToPlay';
import Rules from './pages/Rules';

const rootRoute = createRootRoute({
  component: App,
});

const indexRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/',
  component: Home,
});

const wikiRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/wiki',
  component: Wiki,
});

const mapRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/maailmakaart',
  component: Map,
});

const rulesRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/reeglid',
  component: Rules,
});

const howToPlayRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/how-to-play',
  component: HowToPlay,
});

export const routeTree = rootRoute.addChildren([indexRoute, wikiRoute, mapRoute, rulesRoute, howToPlayRoute]);