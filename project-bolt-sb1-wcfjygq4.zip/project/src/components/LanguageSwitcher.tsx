import React from 'react';
import { useTranslation } from 'react-i18next';
import { Globe } from 'lucide-react';

const LanguageSwitcher: React.FC = () => {
  const { i18n } = useTranslation();

  const toggleLanguage = () => {
    const newLang = i18n.language === 'et' ? 'en' : 'et';
    i18n.changeLanguage(newLang);
  };

  return (
    <button 
      onClick={toggleLanguage}
      className="px-4 py-2 rounded-lg text-gray-300 hover:text-white hover:bg-white/5 transition-colors flex items-center gap-2"
    >
      <Globe className="w-4 h-4" />
      {i18n.language.toUpperCase()}
    </button>
  );
};

export default LanguageSwitcher;