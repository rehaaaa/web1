import React, { useState } from 'react';
import { Command, Home, Map, Briefcase, ShoppingCart, MessageSquare, Search, HelpCircle } from 'lucide-react';
import { motion } from 'framer-motion';

const WikiContent: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');

  const sections = [
    {
      title: 'Teleportatsioon',
      icon: Command,
      commands: [
        { command: '/rtp', description: 'Juhuslik teleport maailmas', cost: '100€' },
        { command: '/tpa [mängija]', description: 'Saadad TP kutse', cost: '200€' },
        { command: '/tpaccept', description: 'Võtab TP kutse vastu' },
        { command: '/tpdeny', description: 'Lükkab TP kutse tagasi' },
        { command: '/tpacancel', description: 'Tühistab saadetud kutse' },
      ],
    },
    {
      title: 'Kodud',
      icon: Home,
      commands: [
        { command: '/sethome [nimi]', description: 'Määrab kodu', cost: '500€, max 3 kodu' },
        { command: '/home [nimi]', description: 'Teleporteerib koju', cost: '75€' },
        { command: '/delhome [nimi]', description: 'Kustutab kodu' },
        { command: '/renamehome [vana] [uus]', description: 'Nimetab kodu ümber' },
      ],
    },
    {
      title: 'Claimimine',
      icon: Map,
      commands: [
        { command: 'Kuldne labidas', description: 'Kasuta kuldset labidat, et enda ala claimida' },
        { command: '/trust [mängija]', description: 'Annab õigused alal' },
        { command: '/untrust [mängija]', description: 'Eemaldab õigused' },
        { command: '/trustlist', description: 'Näitab, kes on trusted' },
        { command: '/abandonclaim', description: 'Kustutab ühe claimi' },
        { command: '/abandonallclaims', description: 'Kustutab kõik claimid' },
        { command: '/buyclaim', description: 'Ostab juurde claimi ala' },
        { command: '/transferclaim [mängija]', description: 'Annab claimi teisele' },
      ],
    },
    {
      title: 'Töökohad',
      icon: Briefcase,
      commands: [
        { command: '/jobs browse', description: 'Kuvab kõik töökohad' },
        { command: '/jobs stats', description: 'Näitab töökoha progressi' },
      ],
    },
    {
      title: 'Oksjon & Shop',
      icon: ShoppingCart,
      commands: [
        { command: '/ah', description: 'Avab oksjonimaja' },
        { command: '/ah sell [hind]', description: 'Müüb eseme oksjonil' },
        { command: '/shop', description: 'Avab poe' },
      ],
    },
    {
      title: 'Bank',
      icon: Command,
      commands: [
        { command: '/warp pank', description: 'Teleporteerib panka' },
      ],
    },
    {
      title: 'BattlePass',
      icon: Command,
      commands: [
        { command: '/battlepass', description: 'Avab BattlePassi menüü' },
      ],
    },
    {
      title: 'ChestShop',
      icon: ShoppingCart,
      commands: [
        { command: '/iteminfo', description: 'Kuvab teavet käes oleva eseme kohta' },
        { command: '/cslist', description: 'Kuvab kõik teie loodud poed' },
        { command: 'ChestShop loomine', description: 'Jäta esimene rida tühjaks.Teine rida on esemete arv, mida soovid osta või müüa. Kolmas rida on ostu- ja müügihindade kombinatsioon. Hind peab sisaldama indikaatorit (nt "B" - hind, mida mängijad maksavad ostes, või "S" - müügihind). Hinnad eraldatakse kooloniga (:). Neljas rida Kirjuta "?".' },
      ],
    },
    {
      title: 'Serveri Warpid',
      icon: Command,
      commands: [
        { command: '/warp Spawn', description: 'Teleporteerib spawni' },
        { command: '/warp PVP', description: 'Teleporteerib PVP alale' },
        { command: '/warp Pank', description: 'Teleporteerib panka' },
        { command: '/warp Lootbox', description: 'Teleporteerib lootboxi alale' },
      ],
    },
    {
      title: 'iWarp',
      icon: Command,
      commands: [
        { command: '/warp <nimi>', description: 'Teleporteerib määratud warpi', cost: '75€' },
        { command: '/setwarp <nimi>', description: 'Loob uue warpi', cost: '50000€ (loomiskulu)' },
        { command: '/delwarp <nimi>', description: 'Kustutab olemasoleva warpi' },
        { command: '/warps', description: 'Näitab kõiki saadaval olevaid warpe' },
        { command: '/warp renew <nimi>', description: 'Uuendab warpi', cost: '500€ (uuendamiskulu)' },
        { command: '/warp move <nimi>', description: 'Liigutab warpi uude asukohta', cost: '25000€ (liigutamiskulu)' },
        { command: '/warp rename <vana> <uus>', description: 'Muudab warpi nime', cost: '25000€ (nime muutmise kulu)' },
        { command: '/warp transfer <nimi> <mängija>', description: 'Annab warpi üle teisele mängijale', cost: '25000€ (ülekandmiskulu)' },
      ],
    },
    {
      title: 'RealisticSeasons',
      icon: Map,
      commands: [
        { description: 'RealisticSeasons plugin lisab Minecrafti’le hooajad, muutes biome’id, ilma ja visuaale dünaamiliselt. Plugin simuleerib kevadet, suve, sügist ja talve, mõjutades temperatuuri, viljade kasvu, mobide käitumist ja muud.' },
        { description: 'Funktsioonid: Biome-põhised hooajad, temperatuurisüsteem, ilmaefektid, viljade kasvu muutused, päeva/öö tsükli muutused, sündmused.' },
      ],
    },
    {
      title: 'Lootboxid',
      icon: ShoppingCart,
      commands: [
        { description: 'Lootboxidest saab avada erinevaid esemeid. Lootboxi võtmeid saab osta poest.' },
      ],
    },
    {
      title: 'SimpleVoiceChat',
      icon: MessageSquare,
      commands: [
        { description: 'SimpleVoiceChat võimaldab mängijatel rääkida omavahel reaalajas. Kasuta /voice, et seadistada häälvestlust.' },
      ],
    },
    {
      title: 'Custom Enchantid',
      icon: Command,
      commands: [
        { description: 'Serveris on erinevad custom enchantid, mis teevad mängimise põnevamaks. Neid saab crate’idest või tavalise enchantimise kaudu.' },
      ],
    },
    {
      title: 'Maailmakaart',
      icon: Map,
      commands: [
        { description: 'Serveri maailmakaart on vaadatav veebilehel map.tptlab.eu.' },
      ],
    },
  ];

  const faqs = [
    {
      question: 'Kuidas ma saan serveriga liituda?',
      answer: 'Lisa server oma Minecraft klienti aadressiga mc.tptlab.eu',
    },
    {
      question: 'Kas server toetab modisid?',
      answer: 'Jah, server toetab teatud modisid. Vaata lubatud modide nimekirja meie Discordist.',
    },
    {
      question: 'Kuidas ma saan oma ala kaitsta?',
      answer: 'Kasuta kuldset labidat, et oma ala claimida. Täpsemad juhised leiad Wiki sektsioonis.',
    },
    {
      question: 'Mis versiooni server kasutab?',
      answer: 'Server töötab versioonil 1.20.4',
    },
  ];

const filteredSections = sections.filter((section) =>
    section.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    section.commands.some((cmd) =>
      (cmd.command && cmd.command.toLowerCase().includes(searchQuery.toLowerCase())) ||
      cmd.description.toLowerCase().includes(searchQuery.toLowerCase())
    )
  );

  return (
    <div className="py-12 px-4 max-w-4xl mx-auto">
      <div className="mb-12">
        <h1 className="text-4xl font-bold mb-8 bg-gradient-to-r from-emerald-400 via-blue-500 to-purple-500 bg-clip-text text-transparent">
          Server Wiki
        </h1>

        {/* Search Bar */}
        <div className="relative mb-8">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="text"
            placeholder="Otsi käske..."
            className="w-full pl-10 pr-4 py-2 bg-gray-800/50 border border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-100"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        {/* Commands */}
        <div className="space-y-6">
          {filteredSections.map((section) => (
            <motion.div
              key={section.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-gray-800/30 backdrop-blur-sm rounded-lg p-4 border border-gray-700/50 hover:border-blue-500/50 transition-colors"
            >
              <div className="flex items-center mb-4">
                <section.icon className="w-5 h-5 text-blue-400 mr-2" />
                <h2 className="text-xl font-semibold text-white">{section.title}</h2>
              </div>
              <div className="space-y-2">
                {section.commands.map((cmd) => (
                  <div
                    key={cmd.command}
                    className="flex items-center justify-between p-2 bg-gray-900/50 rounded-md hover:bg-gray-900/70 transition-colors"
                  >
                    <code className="text-emerald-400 font-mono text-sm">
                      {cmd.command}
                    </code>
                    <div className="flex items-center gap-4">
                      <span className="text-gray-300 text-sm">{cmd.description}</span>
                      {cmd.cost && (
                        <span className="text-xs text-purple-400 font-semibold">
                          {cmd.cost}
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>

        {/* FAQ Section */}
        <div className="mt-16">
          <div className="flex items-center gap-2 mb-6">
            <HelpCircle className="w-6 h-6 text-blue-400" />
            <h2 className="text-2xl font-bold text-white">FAQ</h2>
          </div>
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-gray-800/30 backdrop-blur-sm rounded-lg p-4 border border-gray-700/50"
              >
                <h3 className="text-lg font-semibold text-blue-400 mb-2">{faq.question}</h3>
                <p className="text-gray-300">{faq.answer}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default WikiContent;