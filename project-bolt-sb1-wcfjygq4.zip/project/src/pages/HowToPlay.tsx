import React from 'react';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { 
  TowerControl as GameController, 
  Server, 
  Shield, 
  Users, 
  Download, 
  CheckCircle2, 
  Sparkles, 
  ArrowRight,
  UserPlus
} from 'lucide-react';

const HowToPlay: React.FC = () => {
  const { t } = useTranslation();

  const steps = [
    {
      icon: Download,
      title: 'Hangi Minecraft',
      description: 'Toetame versioone 1.21 - 1.21.4',
      details: [
        'Kasuta Minecraft Java Edition versiooni 1.21 - 1.21.4',
        'Töötab nii ostetud kui ka cracked versiooniga',
        'Uusima versiooni saad minecraft.net lehelt'
      ],
      color: 'emerald'
    },
    {
      icon: Server,
      title: 'Lisa Server',
      description: 'Lisa TPT Lab oma serverite nimekirja',
      details: [
        'Ava Minecraft → Multiplayer',
        'Klõpsa "Add Server"',
        'Serveri aadress: mc.tptlab.eu',
        'Salvesta ja ühenda'
      ],
      color: 'blue'
    },
    {
      icon: UserPlus,
      title: 'Registreeri End',
      description: 'Loo endale konto serveris',
      details: [
        'Kasuta käsku /register [parool] [parool]',
        'Jäta parool meelde, seda läheb vaja sisselogimisel',
        'Järgmine kord kasuta /login [parool]'
      ],
      color: 'purple'
    },
    {
      icon: Shield,
      title: 'Tutvu Reeglitega',
      description: 'Loe läbi serveri reeglid',
      details: [
        'Käitu viisakalt ja austa teisi mängijaid',
        'Keelatud on häkkimine ja petmine',
        'Täpsemad reeglid leiad Discordist'
      ],
      color: 'indigo'
    },
    {
      icon: Users,
      title: 'Liitu Kogukonnaga',
      description: 'Liitu meie Discord serveriga',
      details: [
        'Saa osa kogukonna üritustest',
        'Küsi abi ja jaga kogemusi',
        'Ole kursis uuenduste ja üritustega'
      ],
      color: 'pink'
    }
  ];

  return (
    <div className="min-h-screen pt-20 bg-black">
      {/* Background Effects */}
      <div className="fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-blue-900/20 via-black to-black"></div>
        <div className="absolute inset-0 bg-grid opacity-20"></div>
      </div>

      <div className="container mx-auto px-4 py-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-5xl mx-auto"
        >
          <div className="text-center mb-16">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
              className="inline-block p-2 rounded-2xl bg-gradient-to-r from-blue-500/20 to-purple-500/20 backdrop-blur-sm mb-6"
            >
              <GameController className="w-12 h-12 text-blue-400" />
            </motion.div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent mb-4">
              Kuidas Liituda Serveriga?
            </h1>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Järgi neid lihtsaid samme, et alustada mängimist TPT Lab serveris. Kui vajad abi, 
              küsi julgelt meie Discord serveris!
            </p>
          </div>

          <div className="relative">
            {/* Connection Line */}
            <div className="absolute left-1/2 top-0 bottom-0 w-1 bg-gradient-to-b from-blue-500/20 to-purple-500/20 hidden lg:block"></div>

            {/* Steps */}
            <div className="space-y-12">
              {steps.map((step, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="relative group"
                >
                  <div className={`absolute -inset-1 bg-gradient-to-r from-${step.color}-500/20 to-${step.color}-400/20 rounded-2xl blur-lg opacity-0 group-hover:opacity-100 transition-opacity`}></div>
                  <div className="relative bg-black/40 backdrop-blur-xl border border-white/10 rounded-2xl p-6 lg:p-8 hover:border-white/20 transition-colors">
                    <div className="flex flex-col lg:flex-row gap-6 items-start">
                      {/* Step Number and Icon */}
                      <div className={`flex-shrink-0 w-16 h-16 rounded-xl bg-gradient-to-br from-${step.color}-500/20 to-${step.color}-400/20 flex items-center justify-center`}>
                        <step.icon className={`w-8 h-8 text-${step.color}-400`} />
                      </div>

                      {/* Content */}
                      <div className="flex-grow">
                        <div className="flex items-center gap-3 mb-3">
                          <span className={`text-${step.color}-400 font-mono text-sm`}>SAMM {index + 1}</span>
                          <ArrowRight className={`w-4 h-4 text-${step.color}-400`} />
                        </div>
                        <h3 className="text-2xl font-bold text-white mb-2">{step.title}</h3>
                        <p className="text-gray-400 mb-4">{step.description}</p>
                        
                        {/* Details */}
                        <ul className="space-y-2">
                          {step.details.map((detail, i) => (
                            <li key={i} className="flex items-center gap-2 text-gray-300">
                              <CheckCircle2 className={`w-5 h-5 text-${step.color}-400`} />
                              {detail}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Call to Action */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mt-16 text-center"
          >
            <a
              href="https://discord.gg/DJaTZs7Wxn"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl text-white font-semibold hover:from-blue-500 hover:to-purple-500 transition-all hover:scale-105 group"
            >
              <Sparkles className="w-5 h-5 transition-transform group-hover:rotate-12" />
              Liitu Discordiga
            </a>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
};

export default HowToPlay;