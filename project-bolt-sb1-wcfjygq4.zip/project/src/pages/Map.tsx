import React from 'react';

const Map: React.FC = () => {
  return (
    <div className="min-h-screen pt-16">
      <iframe
        src="https://map.tptlab.eu"
        className="w-full h-[calc(100vh-64px)]"
        title="Server Map"
      />
    </div>
  );
};

export default Map;