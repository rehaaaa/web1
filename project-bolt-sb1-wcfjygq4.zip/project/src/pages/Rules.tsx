import React from 'react';
import { motion } from 'framer-motion';
import { Shield, Users, TowerControl as GameController } from 'lucide-react';

const Rules: React.FC = () => {
  return (
    <div className="min-h-screen pt-24 bg-gray-900">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-4xl mx-auto"
        >
          {/* Discord Rules */}
          <div className="mb-16">
            <div className="flex items-center gap-3 mb-6">
              <Shield className="w-8 h-8 text-purple-400" />
              <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent">
                Discordi Reeglid
              </h1>
            </div>
            <div className="space-y-4 bg-gray-800/30 backdrop-blur-sm rounded-xl p-6 border border-purple-500/20">
              <p className="text-gray-300">• Järgi Discordi Terms Of Service ja Community Guidelines eeskirju</p>
              <p className="text-gray-300">• Kasuta rääkimiseks ainult Eesti keelt</p>
              <p className="text-gray-300">• Ole viisakas ja austa teisi, kasuta roppusi minimaalselt</p>
              <p className="text-gray-300">• Ära spämmi ega tägi inimesi suvaliste asjade jaoks</p>
              <p className="text-gray-300">• Kuula arendajate, moderaatorite ja abilisete sõna. Nende otsused on lõplikud!</p>
              <p className="text-gray-300">• Keelatud on NSFW (18+)/Gore lingid, pildid ja videod</p>
              <p className="text-gray-300">• Hoia poliitilised ja kontroversaalsed teemad oma vestlustest eemal</p>
              <p className="text-gray-300">• Ära promo asju, mis ei lähe kokku Discordi või TPT MC serveriga</p>
              <p className="text-gray-300">• Kasuta kanaleid ainult nendele mõeldud teemadeks</p>
              <p className="text-gray-300">• Keelatud on IP-grabber lingid ja inimeste privaatse info jagamine (DOX-imine)</p>
              <p className="text-gray-300">• Küsimuste tekkimisel ava Ticket</p>
            </div>
          </div>

          {/* Minecraft Server Rules */}
          <div>
            <div className="flex items-center gap-3 mb-6">
              <GameController className="w-8 h-8 text-emerald-400" />
              <h2 className="text-3xl font-bold bg-gradient-to-r from-emerald-400 to-blue-500 bg-clip-text text-transparent">
                Minecrafti Serveri Reeglid
              </h2>
            </div>
            <div className="space-y-4 bg-gray-800/30 backdrop-blur-sm rounded-xl p-6 border border-emerald-500/20">
              <p className="text-gray-300">[1] Ole viisakas. Hoia ropud sõnad endale!</p>
              <p className="text-gray-300">[2] Ära kasuta ebaausaid Minecrafti modifikatsioone.<br/>
                Nt: Cheat-e / Automatiseeritud tegevusi / Exploite / Auto-Clicker-i</p>
              <p className="text-gray-300">[3] Kuula Moderaatoreid/Arendajaid, nende otsused on lõplikud.</p>
              <p className="text-gray-300">[4] Voice Chat-is ära mängi muusikat, ega häirivaid helisi.</p>
              <p className="text-gray-300">[5] Ära aja mõtetut möla chatis ega spämmi seda.</p>
              <p className="text-gray-300">[6] Keelatud on linkide jagamine chat-is.</p>
              <p className="text-gray-300">[7] Ära kasuta kellegi teise identiteeti.</p>
              <p className="text-gray-300">[8] Hoia poliitika ja sensitiivsed teemad serverist eemal.</p>
              <p className="text-gray-300">[9] Kui leiad bug-i/vea pluginas, siis teavita sellest kohe.<br/>
                Mitteteavitamise korral ja selle ärakasutamisel saate karistada.</p>
              <p className="text-gray-300">[10] Ära griefi claimidega.<br/>
                (sh kellegi ala sisse blockimine või kellegi ala juurde meelega claimi tegemine, et nad ei saaks enda claimi suurendada)</p>
              <p className="text-gray-300">[11] Keelatud on Teleportatsiooni ja Claimi sisesed träpid.<br/>
                Siis on võimalust vähemalt träpitud inimesel põgeneda.</p>
              <p className="text-gray-300">[12] Ära campi inimesi nende claimide juures selleks et neid lihtsalt tappa.<br/>
                Mängijad soovivad ka enda claimidest välja minna, et mängu mängida!</p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Rules;