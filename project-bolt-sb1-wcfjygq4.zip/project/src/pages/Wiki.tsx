import React from 'react';
import { motion } from 'framer-motion';
import WikiContent from '../components/WikiContent';

const Wiki: React.FC = () => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.3 }}
      className="min-h-screen bg-gray-900 pt-16"
    >
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-emerald-900/20 via-gray-900 to-gray-900 -z-10">
        <div className="absolute inset-0 dirt-bg opacity-5" />
        <div className="absolute inset-0 grass-overlay" />
      </div>
      <WikiContent />
    </motion.div>
  );
};

export default Wiki;